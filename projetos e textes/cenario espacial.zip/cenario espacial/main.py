import sys
import os
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GL.shaders import compileProgram, compileShader
import numpy as np
from pyrr import matrix44, Vector3

# Importando os módulos fornecidos
from Camera import Camera
from TextureLoader import load_texture
from ObjLoaderSimple import ObjLoaderSimple

# ==========================================================
# SHADERS (GLSL) - Requisito Obrigatório
# ==========================================================
vertex_src = """
#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec2 aTexCoord;

out vec2 TexCoord;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(aPos, 1.0);
    TexCoord = aTexCoord;
}
"""

fragment_src = """
#version 330 core
out vec4 FragColor;

in vec2 TexCoord;

uniform sampler2D texturador;

void main()
{
    FragColor = texture(texturador, TexCoord);
}
"""

def main():
    # Inicialização do Pygame com suporte a OpenGL
    pygame.init()
    display = (1024, 768)
    pygame.display.set_mode(display, DOUBLEBUF | OPENGL)
    pygame.display.set_caption("Trabalho Final CG - Cenario Espacial com Skybox")
    
    # Captura o mouse para controle de câmera estilo FPS
    pygame.event.set_grab(True)
    pygame.mouse.set_visible(False)

    # Configurações básicas do OpenGL
    glEnable(GL_DEPTH_TEST) # Z-Buffer para oclusão correta dos objetos

    # Compilação dos Shaders
    shader = compileProgram(
        compileShader(vertex_src, GL_VERTEX_SHADER),
        compileShader(fragment_src, GL_FRAGMENT_SHADER)
    )
    glUseProgram(shader)

    # ==========================================================
    # GEOMETRIA DO SKYBOX (Cubo interno)
    # ==========================================================
    # Vértices de um cubo unitário (posições X, Y, Z e mapeamento UV simplificado)
    skybox_vertices = np.array([
        # Posições           # UVs
        -1.0,  1.0, -1.0,    0.0, 1.0,
        -1.0, -1.0, -1.0,    0.0, 0.0,
         1.0, -1.0, -1.0,    1.0, 0.0,
         1.0, -1.0, -1.0,    1.0, 0.0,
         1.0,  1.0, -1.0,    1.0, 1.0,
        -1.0,  1.0, -1.0,    0.0, 1.0,

        -1.0, -1.0,  1.0,    0.0, 0.0,
        -1.0, -1.0, -1.0,    1.0, 0.0,
        -1.0,  1.0, -1.0,    1.0, 1.0,
        -1.0,  1.0, -1.0,    1.0, 1.0,
        -1.0,  1.0,  1.0,    0.0, 1.0,
        -1.0, -1.0,  1.0,    0.0, 0.0,

         1.0, -1.0, -1.0,    0.0, 0.0,
         1.0, -1.0,  1.0,    1.0, 0.0,
         1.0,  1.0,  1.0,    1.0, 1.0,
         1.0,  1.0,  1.0,    1.0, 1.0,
         1.0,  1.0, -1.0,    0.0, 1.0,
         1.0, -1.0, -1.0,    0.0, 0.0,

        -1.0, -1.0,  1.0,    0.0, 0.0,
        -1.0,  1.0,  1.0,    0.0, 1.0,
         1.0,  1.0,  1.0,    1.0, 1.0,
         1.0,  1.0,  1.0,    1.0, 1.0,
         1.0, -1.0,  1.0,    1.0, 0.0,
        -1.0, -1.0,  1.0,    0.0, 0.0,

        -1.0,  1.0, -1.0,    0.0, 0.0,
         1.0,  1.0, -1.0,    1.0, 0.0,
         1.0,  1.0,  1.0,    1.0, 1.0,
         1.0,  1.0,  1.0,    1.0, 1.0,
        -1.0,  1.0,  1.0,    0.0, 1.0,
        -1.0,  1.0, -1.0,    0.0, 0.0,

        -1.0, -1.0, -1.0,    0.0, 1.0,
        -1.0, -1.0,  1.0,    0.0, 0.0,
         1.0, -1.0, -1.0,    1.0, 1.0,
         1.0, -1.0, -1.0,    1.0, 1.0,
        -1.0, -1.0,  1.0,    0.0, 0.0,
         1.0, -1.0,  1.0,    1.0, 0.0
    ], dtype=np.float32)

    skybox_vao = glGenVertexArrays(1)
    skybox_vbo = glGenBuffers(1)
    glBindVertexArray(skybox_vao)
    glBindBuffer(GL_ARRAY_BUFFER, skybox_vbo)
    glBufferData(GL_ARRAY_BUFFER, skybox_vertices.nbytes, skybox_vertices, GL_STATIC_DRAW)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * skybox_vertices.itemsize, ctypes.c_void_p(0))
    glEnableVertexAttribArray(0)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * skybox_vertices.itemsize, ctypes.c_void_p(3 * skybox_vertices.itemsize))
    glEnableVertexAttribArray(1)

    # ==========================================================
    # CARREGAMENTO DOS MODELOS 3D E TEXTURAS (CORRIGIDO)
    # ==========================================================
    texture_ids = glGenTextures(4)
    
    # 1. MARTE (Mars)
    mars_buffer, mars_v_count = ObjLoaderSimple.load_obj("objeto/Mars/13903_Mars_v1_l3.obj")
    mars_vao = glGenVertexArrays(1)
    mars_vbo = glGenBuffers(1)
    glBindVertexArray(mars_vao)
    glBindBuffer(GL_ARRAY_BUFFER, mars_vbo)
    glBufferData(GL_ARRAY_BUFFER, mars_buffer.nbytes, mars_buffer, GL_STATIC_DRAW)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * mars_buffer.itemsize, ctypes.c_void_p(0))
    glEnableVertexAttribArray(0)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * mars_buffer.itemsize, ctypes.c_void_p(3 * mars_buffer.itemsize))
    glEnableVertexAttribArray(1)
    load_texture("textura/Mars_diff.jpg", texture_ids[0])

    # 2. FOGUETE (Rocket) - Desativado
    # rocket_buffer, rocket_v_count = ObjLoaderSimple.load_obj("objeto/rocket/12217_rocket_v1_l1.obj")
    # rocket_vao = glGenVertexArrays(1)
    # rocket_vbo = glGenBuffers(1)
    # glBindVertexArray(rocket_vao)
    # glBindBuffer(GL_ARRAY_BUFFER, rocket_vbo)
    # glBufferData(GL_ARRAY_BUFFER, rocket_buffer.nbytes, rocket_buffer, GL_STATIC_DRAW)
    # glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * rocket_buffer.itemsize, ctypes.c_void_p(0))
    # glEnableVertexAttribArray(0)
    # glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * rocket_buffer.itemsize, ctypes.c_void_p(3 * rocket_buffer.itemsize))
    # glEnableVertexAttribArray(1)
    # load_texture("textura/rocket.jpg", texture_ids[1])

    # 2B. NAVE (Spaceship)
    nave_buffer, nave_v_count = ObjLoaderSimple.load_obj("objeto/nave/13889_Spaceship_Tug_v2_l2.obj")
    nave_vao = glGenVertexArrays(1)
    nave_vbo = glGenBuffers(1)
    glBindVertexArray(nave_vao)
    glBindBuffer(GL_ARRAY_BUFFER, nave_vbo)
    glBufferData(GL_ARRAY_BUFFER, nave_buffer.nbytes, nave_buffer, GL_STATIC_DRAW)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * nave_buffer.itemsize, ctypes.c_void_p(0))
    glEnableVertexAttribArray(0)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * nave_buffer.itemsize, ctypes.c_void_p(3 * nave_buffer.itemsize))
    glEnableVertexAttribArray(1)
    load_texture("textura/13889_Spaceship_Tug_diff.jpg", texture_ids[1])

    # 3. ASTEROIDE (Asteroid) - CORRIGIDO: Nome do arquivo é Asteroid.obj
    asteroid_buffer, asteroid_v_count = ObjLoaderSimple.load_obj("objeto/Asteroid/10464_Asteroid_v1_Iterations-2.obj")
    asteroid_vao = glGenVertexArrays(1)
    asteroid_vbo = glGenBuffers(1)
    glBindVertexArray(asteroid_vao)
    glBindBuffer(GL_ARRAY_BUFFER, asteroid_vbo)
    glBufferData(GL_ARRAY_BUFFER, asteroid_buffer.nbytes, asteroid_buffer, GL_STATIC_DRAW)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * asteroid_buffer.itemsize, ctypes.c_void_p(0))
    glEnableVertexAttribArray(0)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * asteroid_buffer.itemsize, ctypes.c_void_p(3 * asteroid_buffer.itemsize))
    glEnableVertexAttribArray(1)
    # A textura dele permanece o nome longo que estava na sua pasta
    load_texture("textura/10464_Asteroid_v1_diffuse.jpg", texture_ids[2])

    # 4. SKYBOX / FUNDO ESTELAR
    load_texture("textura/night-shining.jpg", texture_ids[3])

    # Desvincular buffers
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)

    # ==========================================================
    # MATRIZ DE PROJEÇÃO E CÂMERA
    # ==========================================================
    camera = Camera()
    projection = matrix44.create_perspective_projection_matrix(45.0, display[0]/display[1], 0.1, 200.0)
    
    proj_loc = glGetUniformLocation(shader, "projection")
    view_loc = glGetUniformLocation(shader, "view")
    model_loc = glGetUniformLocation(shader, "model")
    
    glUniformMatrix4fv(proj_loc, 1, GL_FALSE, projection)

    clock = pygame.time.Clock()
    orbit_angle = 0.0

    # Posições do cinturão de asteroides
    posicoes_asteroides = [
        Vector3([20.0, 5.0, -70.0]),
        Vector3([-25.0, -6.0, -85.0]),
        Vector3([12.0, -12.0, -95.0]),
        Vector3([-18.0, 18.0, -75.0]),
        Vector3([30.0, -4.0, -65.0])
    ]

    running = True
    while running:
        dt = clock.tick(60) / 1000.0 
        velocidade_camera = 15.0 * dt

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

        # Captura rotação da câmera pelo mouse
        mouse_x, mouse_y = pygame.mouse.get_rel()
        camera.process_mouse_movement(mouse_x, -mouse_y)

        # Captura movimentação pelas teclas W, A, S, D
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w]:
            camera.process_keyboard("FORWARD", velocidade_camera)
        if keys[pygame.K_s]:
            camera.process_keyboard("BACKWARD", velocidade_camera)
        if keys[pygame.K_a]:
            camera.process_keyboard("LEFT", velocidade_camera)
        if keys[pygame.K_d]:
            camera.process_keyboard("RIGHT", velocidade_camera)

        orbit_angle += 30.0 * dt

        # Limpa os buffers
        glClearColor(0.0, 0.0, 0.0, 1.0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        view = camera.get_view_matrix()
        glUniformMatrix4fv(view_loc, 1, GL_FALSE, view)

        # ------------------------------------------------------
        # PASSO 1: RENDERIZAÇÃO DO SKYBOX (Fundo infinito)
        # ------------------------------------------------------
        glDepthMask(GL_FALSE) # Desativa escrita no Z-buffer temporariamente
        glBindVertexArray(skybox_vao)
        glBindTexture(GL_TEXTURE_2D, texture_ids[3])
        
        # O Skybox deve acompanhar a translação da câmera para parecer infinito
        model_skybox = matrix44.create_from_translation(camera.camera_pos)
        model_skybox = matrix44.multiply(matrix44.create_from_scale(Vector3([120.0, 120.0, 120.0])), model_skybox)
        
        glUniformMatrix4fv(model_loc, 1, GL_FALSE, model_skybox)
        glDrawArrays(GL_TRIANGLES, 0, 36)
        glDepthMask(GL_TRUE) # Reativa o Z-buffer para os objetos normais

        # ------------------------------------------------------
        # PASSO 2: RENDERIZAÇÃO DE MARTE
        # ------------------------------------------------------
        glBindVertexArray(mars_vao)
        glBindTexture(GL_TEXTURE_2D, texture_ids[0])
        
        model_mars = matrix44.create_from_translation(Vector3([18.0, -4.0, -60.0]))
        model_mars = matrix44.multiply(matrix44.create_from_scale(Vector3([0.25, 0.25, 0.25])), model_mars)
        
        glUniformMatrix4fv(model_loc, 1, GL_FALSE, model_mars)
        glDrawArrays(GL_TRIANGLES, 0, mars_v_count)

        # ------------------------------------------------------
        # PASSO 3: RENDERIZAÇÃO DO FOGUETE - Desativado
        # ------------------------------------------------------
        # glBindVertexArray(rocket_vao)
        # glBindTexture(GL_TEXTURE_2D, texture_ids[1])
        # 
        # orbit_center = Vector3([60.0, -4.0, -60.0])
        # orbit_radius = 100.0
        # rocket_pos = Vector3([
        #     orbit_center.x + np.cos(np.radians(orbit_angle)) * orbit_radius,
        #     orbit_center.y + 1.5,
        #     orbit_center.z + np.sin(np.radians(orbit_angle)) * orbit_radius
        # ])
        # model_rocket = matrix44.create_from_translation(rocket_pos)
        # model_rocket = matrix44.multiply(matrix44.create_from_scale(Vector3([0.08, 0.08, 0.08])), model_rocket)
        # 
        # glUniformMatrix4fv(model_loc, 1, GL_FALSE, model_rocket)
        # glDrawArrays(GL_TRIANGLES, 0, rocket_v_count)

        # ------------------------------------------------------
        # PASSO 3B: RENDERIZAÇÃO DA NAVE
        # ------------------------------------------------------
        glBindVertexArray(nave_vao)
        glBindTexture(GL_TEXTURE_2D, texture_ids[1])
        
        orbit_center = Vector3([18.0, -4.0, -60.0])
        orbit_radius = 150.0
        nave_pos = Vector3([
            orbit_center.x - np.cos(np.radians(orbit_angle)) * orbit_radius,
            orbit_center.y + 1.5,
            orbit_center.z - np.sin(np.radians(orbit_angle)) * orbit_radius
        ])
        model_nave = matrix44.create_from_translation(nave_pos)
        model_nave = matrix44.multiply(matrix44.create_from_scale(Vector3([0.02, 0.02, 0.02])), model_nave)
        
        glUniformMatrix4fv(model_loc, 1, GL_FALSE, model_nave)
        glDrawArrays(GL_TRIANGLES, 0, nave_v_count)

        # ------------------------------------------------------
        # PASSO 4: RENDERIZAÇÃO DOS ASTEROIDES
        # ------------------------------------------------------
        # Asteroide removido temporariamente para teste
        # glBindVertexArray(asteroid_vao)
        # glBindTexture(GL_TEXTURE_2D, texture_ids[2])
        # 
        # for pos in posicoes_asteroides:
        #     model_asteroid = matrix44.create_from_translation(pos)
        #     model_asteroid = matrix44.multiply(matrix44.create_from_scale(Vector3([0.1, 0.1, 0.1])), model_asteroid)
        #     
        #     glUniformMatrix4fv(model_loc, 1, GL_FALSE, model_asteroid)
        #     glDrawArrays(GL_TRIANGLES, 0, asteroid_v_count)

        pygame.display.flip()

    # Limpeza da GPU
    glDeleteVertexArrays(1, [skybox_vao, mars_vao, nave_vao, asteroid_vao])
    glDeleteBuffers(1, [skybox_vbo, mars_vbo, nave_vbo, asteroid_vbo])
    glDeleteTextures(texture_ids)
    pygame.quit()

if __name__ == "__main__":
    main()